"""
Preference map key:
0: hiking
1: clubbing
2: beach
3: sightseeing
4: bar hopping
5: food tourism
6: museums
7: historical/cultural sites
8: spa
9: relaxed
10: camping
11: sports
"""

PREFERENCE_MAP = ['hiking',
                  'clubbing',
                  'beach',
                  'sightseeing',
                  'bar hopping',
                  'food tourism',
                  'museums',
                  'historical/cultural sites',
                  'spa',
                  'relaxed',
                  'camping',
                  'sports'
                  ]
